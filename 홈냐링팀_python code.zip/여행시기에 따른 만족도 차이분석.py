#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns


# In[2]:


from IPython.core.display import display, HTML

## 전체 구간을 넓게
display(HTML("<style>.container { width:100% !important; }</style>"))
## 각 컬럼 width 최대로
pd.set_option('display.max_colwidth', -1)
## rows 500
pd.set_option('display.max_rows', 500)
## columns
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


# In[3]:


df = pd.read_csv('2019 국민여행조사_국내여행.csv')
print(df)


# ## 여행 시기별 만족도 차이

# In[4]:


시기별데이터 = df[df['D_TRA1_SYEAR'].isna()==False]
print(시기별데이터)


# In[5]:


print(시기별데이터[['D_TRA1_SYEAR','D_TRA1_SMONTH','D_TRA1_SDAY']])


# ### 시기별 구분
# **1) 황금연휴**
# - 설날 : 2월 2일 ~ 6일
# - 추석 : 9월 12일 ~ 15일
# - 삼일절 : 3월 1일 ~ 3일
# - 어린이날, 대체휴일 : 5월 4~6일
# - 석가탄신일 : 5월 11~12일
# - 현충일 : 6월 6~9일
# - 광복절 : 8월 15~18일
# - 개천절 : 10월 3~6일
# - 한글날 : 10월 9일
# - 성탄절 : 12월 25일
#   
# **2) 여름성수기**  
# 7월 1일~8월 11일
#   
# **3) 겨울성수기**  
# 1월 1일~2월 8일,  
# 12월 23일~31일
#   
# **4) 주말(황금연휴와 성수기 제외)**
# - 2월 : 9~10,16~17,23~24
# - 3월 : 9~10,16~17,23~24,30~31
# - 4월 : 6~7,13~14,20~21,27~28
# - 5월 : 18~19.25~26
# - 6월 : 1~2,15~16,22~23,29~30
# - 8월 : 24~25,31
# - 9월 : 1, 7~8,21~22,28~29
# - 10월 : 12~13,19~20,26~27
# - 11월 : 2~3, 9~10,16~17,23~24,30
# - 12월 : 1, 7~8,21~22
# 
# **5) 주중(황금연휴와 성수기 제외)**  
# 나머지 index

# In[6]:


# 2018 년 데이터 깔끔히 버리기( 27321 -> 27281 개의 데이터)
작년데이터인덱스 = 시기별데이터[시기별데이터['D_TRA1_SYEAR']==2018].index
시기별데이터 = 시기별데이터.drop(작년데이터인덱스, axis=0)
print(시기별데이터)


# In[7]:


# 월별 데이터프레임 만들기
데이터1월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==1]
데이터2월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==2]
데이터3월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==3]
데이터4월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==4]
데이터5월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==5]
데이터6월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==6]
데이터7월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==7]
데이터8월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==8]
데이터9월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==9]
데이터10월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==10]
데이터11월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==11]
데이터12월 = 시기별데이터[시기별데이터['D_TRA1_SMONTH']==12]


# In[8]:


#################################### 황금연휴 데이터 #########################################
# 설날 : 2월 2일 ~ 6일
황금연휴_설날 = 데이터2월[(데이터2월['D_TRA1_SDAY']==2)|(데이터2월['D_TRA1_SDAY']==3)|(데이터2월['D_TRA1_SDAY']==4)|(데이터2월['D_TRA1_SDAY']==5)|(데이터2월['D_TRA1_SDAY']==6)] 
# 추석 : 9월 12일 ~ 15일
황금연휴_추석 = 데이터9월[(데이터9월['D_TRA1_SDAY']==12)|(데이터9월['D_TRA1_SDAY']==13)|(데이터9월['D_TRA1_SDAY']==14)|(데이터9월['D_TRA1_SDAY']==15)] 
# 삼일절 : 3월 1일 ~ 3일
황금연휴_삼일절 = 데이터3월[(데이터3월['D_TRA1_SDAY']==1)|(데이터3월['D_TRA1_SDAY']==2)|(데이터3월['D_TRA1_SDAY']==3)] 
# 어린이날, 대체휴일 : 5월 4~6일
황금연휴_어린이날 = 데이터5월[(데이터5월['D_TRA1_SDAY']==4)|(데이터5월['D_TRA1_SDAY']==5)|(데이터5월['D_TRA1_SDAY']==6)] 
# 석가탄신일 : 5월 11~12일
황금연휴_석가탄신일 = 데이터5월[(데이터5월['D_TRA1_SDAY']==11)|(데이터5월['D_TRA1_SDAY']==12)]
# 현충일 : 6월 6~9일
황금연휴_현충일 = 데이터6월[(데이터6월['D_TRA1_SDAY']==6)|(데이터6월['D_TRA1_SDAY']==7)|(데이터6월['D_TRA1_SDAY']==8)|(데이터6월['D_TRA1_SDAY']==9)] 
# 광복절 : 8월 15~18일
황금연휴_광복절 = 데이터8월[(데이터8월['D_TRA1_SDAY']==15)|(데이터8월['D_TRA1_SDAY']==16)|(데이터8월['D_TRA1_SDAY']==17)|(데이터8월['D_TRA1_SDAY']==18)]
# 개천절 : 10월 3~6일
황금연휴_개천절 = 데이터10월[(데이터10월['D_TRA1_SDAY']==3)|(데이터10월['D_TRA1_SDAY']==4)|(데이터10월['D_TRA1_SDAY']==5)|(데이터10월['D_TRA1_SDAY']==6)]
# 한글날 : 10월 9일
황금연휴_한글날 = 데이터10월[데이터10월['D_TRA1_SDAY']==9]
# 성탄절 : 12월 25일
황금연휴_성탄절 = 데이터12월[데이터12월['D_TRA1_SDAY']==25]

황금연휴 = pd.concat([황금연휴_설날,황금연휴_추석,황금연휴_삼일절,황금연휴_어린이날,황금연휴_석가탄신일,황금연휴_현충일,황금연휴_광복절,황금연휴_개천절,황금연휴_한글날,황금연휴_성탄절])
황금연휴인덱스 = 황금연휴.index


# In[9]:


####################################여름성수기######################################
# 7월 1일~8월 11일
여름성수기_7월 = 데이터7월
여름성수기_8월 = 데이터8월[(데이터8월['D_TRA1_SDAY']==1)|(데이터8월['D_TRA1_SDAY']==2)|(데이터8월['D_TRA1_SDAY']==3)|(데이터8월['D_TRA1_SDAY']==4)|
                (데이터8월['D_TRA1_SDAY']==5)|(데이터8월['D_TRA1_SDAY']==6)|(데이터8월['D_TRA1_SDAY']==7)|(데이터8월['D_TRA1_SDAY']==8)|
                (데이터8월['D_TRA1_SDAY']==9)|(데이터8월['D_TRA1_SDAY']==10)|(데이터8월['D_TRA1_SDAY']==11)]
여름성수기 = pd.concat([여름성수기_7월,여름성수기_8월])
여름성수기인덱스 = 여름성수기.index


# In[10]:


####################################겨울성수기######################################
### 1월 1일~2월 8일, 12월 23일~31일
겨울성수기_1월 = 데이터1월
겨울성수기_2월 = 데이터2월[(데이터2월['D_TRA1_SDAY']==1)|(데이터2월['D_TRA1_SDAY']==2)|(데이터2월['D_TRA1_SDAY']==3)|(데이터2월['D_TRA1_SDAY']==4)|
                (데이터2월['D_TRA1_SDAY']==5)|(데이터2월['D_TRA1_SDAY']==6)|(데이터2월['D_TRA1_SDAY']==7)|(데이터2월['D_TRA1_SDAY']==8)]
겨울성수기_12월 = 데이터12월[(데이터12월['D_TRA1_SDAY']==23)|(데이터12월['D_TRA1_SDAY']==24)|(데이터12월['D_TRA1_SDAY']==25)|(데이터12월['D_TRA1_SDAY']==26)|
                  (데이터12월['D_TRA1_SDAY']==27)|(데이터12월['D_TRA1_SDAY']==28)|(데이터12월['D_TRA1_SDAY']==29)|(데이터12월['D_TRA1_SDAY']==30)|(데이터12월['D_TRA1_SDAY']==31)]
겨울성수기 = pd.concat([겨울성수기_1월,겨울성수기_2월,겨울성수기_12월])
겨울성수기인덱스 = 겨울성수기.index


# In[11]:


######################################주말########################################
# 2월 : 9~10,16~17,23~24
주말_2월 = 데이터2월[(데이터2월['D_TRA1_SDAY']==9)|(데이터2월['D_TRA1_SDAY']==10)|(데이터2월['D_TRA1_SDAY']==16)|(데이터2월['D_TRA1_SDAY']==17)|
              (데이터2월['D_TRA1_SDAY']==23)|(데이터2월['D_TRA1_SDAY']==24)]
# 3월 : 9~10,16~17,23~24,30~31
주말_3월 = 데이터3월[(데이터3월['D_TRA1_SDAY']==9)|(데이터3월['D_TRA1_SDAY']==10)|(데이터3월['D_TRA1_SDAY']==16)|(데이터3월['D_TRA1_SDAY']==17)|
              (데이터3월['D_TRA1_SDAY']==23)|(데이터3월['D_TRA1_SDAY']==24)|(데이터3월['D_TRA1_SDAY']==30)|(데이터3월['D_TRA1_SDAY']==31)]
# 4월 : 6~7,13~14,20~21,27~28
주말_4월 = 데이터4월[(데이터4월['D_TRA1_SDAY']==6)|(데이터4월['D_TRA1_SDAY']==7)|(데이터4월['D_TRA1_SDAY']==13)|(데이터4월['D_TRA1_SDAY']==14)|
             (데이터4월['D_TRA1_SDAY']==20)|(데이터4월['D_TRA1_SDAY']==21)|(데이터4월['D_TRA1_SDAY']==27)|(데이터4월['D_TRA1_SDAY']==28)]
# 5월 : 18~19.25~26
주말_5월 = 데이터5월[(데이터5월['D_TRA1_SDAY']==18)|(데이터5월['D_TRA1_SDAY']==19)|(데이터5월['D_TRA1_SDAY']==25)|(데이터5월['D_TRA1_SDAY']==26)]
# 6월 : 1~2,15~16,22~23,29~30
주말_6월 = 데이터6월[(데이터6월['D_TRA1_SDAY']==1)|(데이터6월['D_TRA1_SDAY']==2)|(데이터6월['D_TRA1_SDAY']==15)|(데이터6월['D_TRA1_SDAY']==16)|
             (데이터6월['D_TRA1_SDAY']==22)|(데이터6월['D_TRA1_SDAY']==23)|(데이터6월['D_TRA1_SDAY']==29)|(데이터6월['D_TRA1_SDAY']==30)] 
# 8월 : 24~25,31
주말_8월 = 데이터8월[(데이터8월['D_TRA1_SDAY']==24)|(데이터8월['D_TRA1_SDAY']==25)|(데이터8월['D_TRA1_SDAY']==31)]
# 9월 : 1, 7~8,21~22,28~29
주말_9월 = 데이터9월[(데이터9월['D_TRA1_SDAY']==1)|(데이터9월['D_TRA1_SDAY']==7)|(데이터9월['D_TRA1_SDAY']==8)|
      (데이터9월['D_TRA1_SDAY']==21)|(데이터9월['D_TRA1_SDAY']==22)|(데이터9월['D_TRA1_SDAY']==28)|(데이터9월['D_TRA1_SDAY']==29)] 
# 10월 : 12~13,19~20,26~27
주말_10월 = 데이터10월[(데이터10월['D_TRA1_SDAY']==12)|(데이터10월['D_TRA1_SDAY']==13)|(데이터10월['D_TRA1_SDAY']==19)|(데이터10월['D_TRA1_SDAY']==20)|
               (데이터10월['D_TRA1_SDAY']==26)|(데이터10월['D_TRA1_SDAY']==27)]
# 11월 : 2~3, 9~10,16~17,23~24,30
주말_11월 = 데이터11월[(데이터11월['D_TRA1_SDAY']==2)|(데이터11월['D_TRA1_SDAY']==3)|(데이터11월['D_TRA1_SDAY']==9)|(데이터11월['D_TRA1_SDAY']==10)|(데이터11월['D_TRA1_SDAY']==16)|
               (데이터11월['D_TRA1_SDAY']==17)|(데이터11월['D_TRA1_SDAY']==23)|(데이터11월['D_TRA1_SDAY']==24)|(데이터11월['D_TRA1_SDAY']==30)]
# 12월 : 1, 7~8,21~22
주말_12월 = 데이터12월[(데이터12월['D_TRA1_SDAY']==1)|(데이터12월['D_TRA1_SDAY']==7)|(데이터12월['D_TRA1_SDAY']==8)|(데이터12월['D_TRA1_SDAY']==21)|(데이터12월['D_TRA1_SDAY']==22)]

주말 = pd.concat([주말_2월,주말_3월,주말_4월,주말_5월,주말_6월,주말_8월,주말_9월,주말_10월,주말_11월,주말_12월])
주말인덱스 = 주말.index


# In[12]:


##############################주중#####################################
주중을위한인덱스리스트중복 = list(황금연휴인덱스)+list(여름성수기인덱스)+list(겨울성수기인덱스)+list(주말인덱스)
주중을위한인덱스리스트중복제거 = set(주중을위한인덱스리스트중복)
주중 = 시기별데이터.drop(주중을위한인덱스리스트중복제거, axis=0)


# ### 여행 시기별 여행 활동 차이 분석

# In[41]:


# 황금 연휴 Nan 있는 행 제거, 여행활동 데이터 프레임 생성
황금연휴_만족도 = 황금연휴.drop(황금연휴[황금연휴['A12'].isnull()].index, axis=0)
황금연휴_특정만족도 =  황금연휴_만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_10', 'A3_11','A3_12',
                        'A3_13','A3_14','A3_15','A3_16','A3_17','A3_18','A3_19','A3_20','A3_21','A12']]
황금연휴_특정만족도 = 황금연휴_특정만족도.fillna(0)
for i in 황금연휴_특정만족도.columns[:-1]:
    황금연휴_특정만족도.loc[황금연휴_특정만족도[i]!=0, i] = 1

# 여름성수기 Nan 있는 행 제거, 여행활동 데이터 프레임 생성
여름성수기_만족도 = 여름성수기.drop(여름성수기[여름성수기['A12'].isnull()].index, axis=0)
여름성수기_특정만족도 =  여름성수기_만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_10', 'A3_11','A3_12',
                        'A3_13','A3_14','A3_15','A3_16','A3_17','A3_18','A3_19','A3_20','A3_21','A12']]
여름성수기_특정만족도 = 여름성수기_특정만족도.fillna(0)
for i in 여름성수기_특정만족도.columns[:-1]:
    여름성수기_특정만족도.loc[여름성수기_특정만족도[i]!=0, i] = 1

# 겨울성수기 Nan 있는 행 제거, 여행활동 데이터 프레임 생성
겨울성수기_만족도 = 겨울성수기.drop(겨울성수기[겨울성수기['A12'].isnull()].index, axis=0)
겨울성수기_특정만족도 =  겨울성수기_만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_10', 'A3_11','A3_12',
                        'A3_13','A3_14','A3_15','A3_16','A3_17','A3_18','A3_19','A3_20','A3_21','A12']]
겨울성수기_특정만족도 = 겨울성수기_특정만족도.fillna(0)
for i in 겨울성수기_특정만족도.columns[:-1]:
    겨울성수기_특정만족도.loc[겨울성수기_특정만족도[i]!=0, i] = 1

# 주말 Nan 있는 행 제거, 여행활동 데이터 프레임 생성
주말_만족도 = 주말.drop(주말[주말['A12'].isnull()].index, axis=0)
주말_특정만족도 =  주말_만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_10', 'A3_11','A3_12',
                        'A3_13','A3_14','A3_15','A3_16','A3_17','A3_18','A3_19','A3_20','A3_21','A12']]
주말_특정만족도 = 주말_특정만족도.fillna(0)
for i in 주말_특정만족도.columns[:-1]:
    주말_특정만족도.loc[주말_특정만족도[i]!=0, i] = 1

# 주중 Nan 있는 행 제거, 여행활동 데이터 프레임 생성
주중_만족도 = 주중.drop(주중[주중['A12'].isnull()].index, axis=0)
주중_특정만족도 =  주중_만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_10', 'A3_11','A3_12',
                        'A3_13','A3_14','A3_15','A3_16','A3_17','A3_18','A3_19','A3_20','A3_21','A12']]
주중_특정만족도 = 주중_특정만족도.fillna(0)
for i in 주중_특정만족도.columns[:-1]:
    주중_특정만족도.loc[주중_특정만족도[i]!=0, i] = 1


# In[42]:


print('황금연휴 기간의 여행자 수는 ', len(황금연휴_특정만족도),'명')
print('여름성수기 기간의 여행자 수는 ',len(여름성수기_특정만족도), '명')
print('겨울성수기 기간의 여행자 수는 ', len(겨울성수기_특정만족도), '명')
print('주말 기간의 여행자 수는 ',len(주말_특정만족도), '명')
print('주중 기간의 여행자 수는 ', len(주중_특정만족도), '명')


# In[38]:


황금연휴_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].mean()


# In[39]:


황금연휴_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].sum()


# In[45]:


여름성수기_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].sum()


# In[46]:


여름성수기_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].mean()


# In[47]:


겨울성수기_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].sum()


# In[48]:


겨울성수기_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].mean()


# In[50]:


주말_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].sum()


# In[49]:


주말_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].mean()


# In[53]:


주중_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].sum()


# In[54]:


주중_특정만족도[['A3_1','A3_2','A3_3','A3_4','A3_5','A3_6','A3_7','A3_8','A3_9','A3_12','A3_18']].mean()


# ## 여행 시기별 여행 만족도 차이 분석

# In[14]:


# 시기별 전반적 만족도 차이_황금연휴
from matplotlib.pyplot import show
# 실질 개수로 percent 구하기
a=len(황금연휴)-len(황금연휴[황금연휴['A12'].isnull()])

ax = sns.countplot(x="A12", data=황금연휴)
ax.set_title('Satisfaction of GoldHoliday trip')
ax.set_xlabel('Satisfaction')
ax.set_ylabel('Count')
for p in ax.patches:
    left, bottom, width, height = p.get_bbox().bounds
    ax.annotate("%.1f %%"%(height/a*100), (left+width/2, height*1.01), ha='center')


# In[15]:


# 시기별 전반적 만족도 차이_여름성수기
a=len(여름성수기)-len(여름성수기[여름성수기['A12'].isnull()])

ax = sns.countplot(x="A12", data=여름성수기)
ax.set_title('Satisfaction of Summer trip')
ax.set_xlabel('Satisfaction')
ax.set_ylabel('Count')
for p in ax.patches:
    left, bottom, width, height = p.get_bbox().bounds
    ax.annotate("%.1f %%"%(height/a*100), (left+width/2, height*1.01), ha='center')


# In[16]:


# 시기별 전반적 만족도 차이_겨울성수기
a=len(겨울성수기)-len(겨울성수기[겨울성수기['A12'].isnull()])

ax = sns.countplot(x="A12", data=겨울성수기)
ax.set_title('Satisfaction of Winter trip')
ax.set_xlabel('Satisfaction')
ax.set_ylabel('Count')
for p in ax.patches:
    left, bottom, width, height = p.get_bbox().bounds
    ax.annotate("%.1f %%"%(height/a*100), (left+width/2, height*1.01), ha='center')


# In[55]:


# 시기별 전반적 만족도 차_주말
a=len(주말)-len(주말[주말['A12'].isnull()])
print(a)
ax = sns.countplot(x="A12", data=주말)
ax.set_title('Satisfaction of Weekend trip')
ax.set_xlabel('Satisfaction')
ax.set_ylabel('Count')
for p in ax.patches:
    left, bottom, width, height = p.get_bbox().bounds
    ax.annotate("%.1f %%"%(height/a*100), (left+width/2, height*1.01), ha='center')


# In[18]:


# 시기별 전반적 만족도 차_주중
a=len(주중)-len(주중[주중['A12'].isnull()])

ax = sns.countplot(x="A12", data=주중)
ax.set_title('Satisfaction of Weekday trip')
ax.set_xlabel('Satisfaction')
ax.set_ylabel('Count')
for p in ax.patches:
    left, bottom, width, height = p.get_bbox().bounds
    ax.annotate("%.1f %%"%(height/a*100), (left+width/2, height*1.01), ha='center')


# ## 여행 시기별 주 이용지역 Top5 선정 -> 최종 지역 선정
# 
# 11 서울특별시  
# 21 부산광역시  
# 22 대구광역시  
# 23 인천광역시  
# 24 광주광역시  
# 25 대전광역시  
# 26 울산광역시  
# 31 경기도  
# 32 강원도  
# 33 충청북도  
# 34 충청남도  
# 37 경상북도  
# 38 경상남도  
# 35 전라북도  
# 36 전라남도  
# 39 제주특별자치도  

# In[19]:


sdsd = pd.DataFrame(황금연휴['국내_여행방문지_국내전체1'].value_counts())
sdsd = sdsd.reset_index()
sdsd.columns = ['지역','여행자수']


# In[20]:


def region_transformer(data):
    data_region = pd.DataFrame(data['국내_여행방문지_국내전체1'].value_counts())
    data_region = data_region.reset_index()
    data_region.columns = ['지역','여행자수']
    for i in range(len(data_region)):
        if data_region.loc[i,'지역'] == 11:
            data_region.loc[i,'지역'] = '서울특별시'
        elif data_region['지역'][i] == 21:
            data_region['지역'][i] = '부산광역시'
        elif data_region['지역'][i] == 22:
            data_region['지역'][i] = '대구광역시'
        elif data_region['지역'][i] == 23:
            data_region['지역'][i] = '인천광역시'
        elif data_region['지역'][i] == 24:
            data_region['지역'][i] = '광주광역시'
        elif data_region['지역'][i] == 25:
            data_region['지역'][i] = '대전광역시'
        elif data_region['지역'][i] == 26:
            data_region['지역'][i] = '울산광역시'
        elif data_region['지역'][i] == 31:
            data_region['지역'][i] = '경기도'
        elif data_region['지역'][i] == 32:
            data_region['지역'][i] = '강원도'
        elif data_region['지역'][i] ==33:
            data_region['지역'][i] = '충청북도'
        elif data_region['지역'][i] ==34:
            data_region['지역'][i] = '충청남도'
        elif data_region['지역'][i] == 37:
            data_region['지역'][i] = '경상북도'
        elif data_region['지역'][i] == 38:
            data_region['지역'][i] = '경상남도'
        elif data_region['지역'][i] == 35:
            data_region['지역'][i] = '전라북도'
        elif data_region['지역'][i] == 36:
            data_region['지역'][i] = '전라남도'
        elif data_region['지역'][i] == 39:
            data_region['지역'][i] = '제주특별자치도'
        else: data_region['지역'][i] = '기타지역'
    return data_region


# In[21]:


황금연휴_지역 = region_transformer(황금연휴)
여름성수기_지역 = region_transformer(여름성수기)
겨울성수기_지역 = region_transformer(겨울성수기)
주말_지역 = region_transformer(주말)
주중_지역 = region_transformer(주중)


# In[22]:


황금연휴_지역.head()


# In[23]:


여름성수기_지역.head()


# In[59]:


겨울성수기_지역.head()


# In[25]:


주말_지역.head()


# In[26]:


주중_지역.head()

